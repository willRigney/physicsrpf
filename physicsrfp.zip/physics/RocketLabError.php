<!DOCTYPE html>

<html>

<head>
<h1 align="center">Rocket Lab Calculations</h1>
<hr>
<style type="text/css">
body{
background-color:#d0e4fe;
}
p#error{
color:red;
}
p#right{
	font-size:small;
	text-align:right;
}
</style>
</head>

<body>
<!-- credit: old source used as base -->
<p id="error">Error</p>
<p>Please check if you:<br>

Filled in all the sections<br>
Do not enter data for 90 degrees <br>
Uncollected data fields should be filled out as 0 <br>
Entered your first and last name and period at the bottom.<br>
Entered your period at the bottom as a number. (e.g. "3")<br>
Only type in the number without any units.<br>
Press the back button to fix the errors.<br></p>
</body>


</html>
<?php
unlink ("Answers.csv");
echo "File deleted."
?>
<!--
Michael Voecks
-->

<?php

	/********************************************Row 1***********************************************************************************/

	if(isset($_POST['1a']) && is_numeric($_POST['1a']))
		$a1 = $_POST['1a'];
	else{
		header("Location: BarrelJumpError.html");
		exit;
	}
	if(isset($_POST['1b']) && is_numeric($_POST['1b']))
		$b1 = $_POST['1b'];
	else{
		header("Location: BarrelJumpError.html");
		exit;
	}
	if(isset($_POST['1c']) && is_numeric($_POST['1c']))
		$c1 = $_POST['1c'];
	else{
		header("Location: BarrelJumpError.html");
		exit;
	}
	if(isset($_POST['1d']) && is_numeric($_POST['1d']))
		$d1 = $_POST['1d'];
	else{
		header("Location: BarrelJumpError.html");
		exit;
	}
	if(isset($_POST['1e']) && is_numeric($_POST['1e']))
		$e1 = $_POST['1e'];
	else{
		header("Location: BarrelJumpError.html");
		exit;
	}
	if(isset($_POST['1f']) && is_numeric($_POST['1f']))
		$f1 = $_POST['1f'];
	else{
		header("Location: BarrelJumpError.html");
		exit;
	}
	if(isset($_POST['1g']) && is_numeric($_POST['1g']))
		$g1 = $_POST['1g'];
	else{
		header("Location: BarrelJumpError.html");
		exit;
	}
	if(isset($_POST['1h']) && is_numeric($_POST['1h']))
		$h1 = $_POST['1h'];
	else{
		header("Location: BarrelJumpError.html");
		exit;
	}
	if(isset($_POST['1i']) && is_numeric($_POST['1i']))
		$i1 = $_POST['1i'];
	else{
		header("Location: BarrelJumpError.html");
		exit;
	}
	
	/********************************************Row 2***********************************************************************************/
	if(isset($_POST['2a']) && is_numeric($_POST['2a']))
		$a2 = $_POST['2a'];
	else{
		header("Location: BarrelJumpError.html");
		exit;
	}
	if(isset($_POST['2b']) && is_numeric($_POST['2b']))
		$b2 = $_POST['2b'];
	else{
		header("Location: BarrelJumpError.html");
		exit;
	}
	if(isset($_POST['2c']) && is_numeric($_POST['2c']))
		$c2 = $_POST['2c'];
	else{
		header("Location: BarrelJumpError.html");
		exit;
	}
	if(isset($_POST['2d']) && is_numeric($_POST['2d']))
		$d2 = $_POST['2d'];
	else{
		header("Location: BarrelJumpError.html");
		exit;
	}
	if(isset($_POST['2e']) && is_numeric($_POST['2e']))
		$e2 = $_POST['2e'];
	else{
		header("Location: BarrelJumpError.html");
		exit;
	}
	if(isset($_POST['2f']) && is_numeric($_POST['2f']))
		$f2 = $_POST['2f'];
	else{
		header("Location: BarrelJumpError.html");
		exit;
	}
	if(isset($_POST['2g']) && is_numeric($_POST['2g']))
		$g2 = $_POST['2g'];
	else{
		header("Location: BarrelJumpError.html");
		exit;
	}
	if(isset($_POST['2h']) && is_numeric($_POST['2h']))
		$h2 = $_POST['2h'];
	else{
		header("Location: BarrelJumpError.html");
		exit;
	}
	if(isset($_POST['2i']) && is_numeric($_POST['2i']))
		$i2 = $_POST['2i'];
	else{
		header("Location: BarrelJumpError.html");
		exit;
	}
	
	/********************************************Row 3***********************************************************************************/

	if(isset($_POST['3a']) && is_numeric($_POST['3a']))
		$a3 = $_POST['3a'];
	else{
		header("Location: BarrelJumpError.html");
		exit;
	}
	if(isset($_POST['3b']) && is_numeric($_POST['3b']))
		$b3 = $_POST['3b'];
	else{
		header("Location: BarrelJumpError.html");
		exit;
	}
	if(isset($_POST['3c']) && is_numeric($_POST['3c']))
		$c3 = $_POST['3c'];
	else{
		header("Location: BarrelJumpError.html");
		exit;
	}
	if(isset($_POST['3d']) && is_numeric($_POST['3d']))
		$d3 = $_POST['3d'];
	else{
		header("Location: BarrelJumpError.html");
		exit;
	}
	if(isset($_POST['3e']) && is_numeric($_POST['3e']))
		$e3 = $_POST['3e'];
	else{
		header("Location: BarrelJumpError.html");
		exit;
	}
	if(isset($_POST['3f']) && is_numeric($_POST['3f']))
		$f3 = $_POST['3f'];
	else{
		header("Location: BarrelJumpError.html");
		exit;
	}
	if(isset($_POST['3g']) && is_numeric($_POST['3g']))
		$g3 = $_POST['3g'];
	else{
		header("Location: BarrelJumpError.html");
		exit;
	}
	if(isset($_POST['3h']) && is_numeric($_POST['3h']))
		$h3 = $_POST['3h'];
	else{
		header("Location: BarrelJumpError.html");
		exit;
	}
	if(isset($_POST['3i']) && is_numeric($_POST['3i']))
		$i3 = $_POST['3i'];
	else{
		header("Location: BarrelJumpError.html");
		exit;
	}
	
	/********************************************Row 4***********************************************************************************/

	if(isset($_POST['4a']) && is_numeric($_POST['4a']))
		$a4 = $_POST['4a'];
	else{
		header("Location: BarrelJumpError.html");
		exit;
	}
	if(isset($_POST['4b']) && is_numeric($_POST['4b']))
		$b4 = $_POST['4b'];
	else{
		header("Location: BarrelJumpError.html");
		exit;
	}
	if(isset($_POST['4c']) && is_numeric($_POST['4c']))
		$c4 = $_POST['4c'];
	else{
		header("Location: BarrelJumpError.html");
		exit;
	}
	if(isset($_POST['4d']) && is_numeric($_POST['4d']))
		$d4 = $_POST['4d'];
	else{
		header("Location: BarrelJumpError.html");
		exit;
	}
	if(isset($_POST['4e']) && is_numeric($_POST['4e']))
		$e4 = $_POST['4e'];
	else{
		header("Location: BarrelJumpError.html");
		exit;
	}
	if(isset($_POST['4f']) && is_numeric($_POST['4f']))
		$f4 = $_POST['4f'];
	else{
		header("Location: BarrelJumpError.html");
		exit;
	}
	if(isset($_POST['4g']) && is_numeric($_POST['4g']))
		$g4 = $_POST['4g'];
	else{
		header("Location: BarrelJumpError.html");
		exit;
	}
	if(isset($_POST['4h']) && is_numeric($_POST['4h']))
		$h4 = $_POST['4h'];
	else{
		header("Location: BarrelJumpError.html");
		exit;
	}
	if(isset($_POST['4i']) && is_numeric($_POST['4i']))
		$i4 = $_POST['4i'];
	else{
		header("Location: BarrelJumpError.html");
		exit;
	}
	
	/********************************************Row 5***********************************************************************************/

	if(isset($_POST['5a']) && is_numeric($_POST['5a']))
		$a5 = $_POST['5a'];
	else{
		header("Location: BarrelJumpError.html");
		exit;
	}
	if(isset($_POST['5b']) && is_numeric($_POST['5b']))
		$b5 = $_POST['5b'];
	else{
		header("Location: BarrelJumpError.html");
		exit;
	}
	if(isset($_POST['5c']) && is_numeric($_POST['5c']))
		$c5 = $_POST['5c'];
	else{
		header("Location: BarrelJumpError.html");
		exit;
	}
	if(isset($_POST['5d']) && is_numeric($_POST['5d']))
		$d5 = $_POST['5d'];
	else{
		header("Location: BarrelJumpError.html");
		exit;
	}
	if(isset($_POST['5e']) && is_numeric($_POST['5e']))
		$e5 = $_POST['5e'];
	else{
		header("Location: BarrelJumpError.html");
		exit;
	}
	if(isset($_POST['5f']) && is_numeric($_POST['5f']))
		$f5 = $_POST['5f'];
	else{
		header("Location: BarrelJumpError.html");
		exit;
	}
	if(isset($_POST['5g']) && is_numeric($_POST['5g']))
		$g5 = $_POST['5g'];
	else{
		header("Location: BarrelJumpError.html");
		exit;
	}
	if(isset($_POST['5h']) && is_numeric($_POST['5h']))
		$h5 = $_POST['5h'];
	else{
		header("Location: BarrelJumpError.html");
		exit;
	}
	if(isset($_POST['5i']) && is_numeric($_POST['5i']))
		$i5 = $_POST['5i'];
	else{
		header("Location: BarrelJumpError.html");
		exit;
	}
	
	
	
	if(isset($_POST['fname']))
		$fname = htmlspecialchars($_POST['fname']);
	else{
		header("Location: BarrelJumpError.html");
		exit;
	}
	if(isset($_POST['lname']))
		$lname = htmlspecialchars($_POST['lname']);
	else{
		header("Location: BarrelJumpError.html");
		exit;
	}
	if(isset($_POST['period']) && is_numeric($_POST['period']))
		$period = $_POST['period'];
	else{
		header("Location: BarrelJumpError.html");
		exit;
	}
	$correct = 0;
	$score = 0;
?>

<!DOCTYPE html>
<html>
<head>
	<title>Barrel Jump Lab</title>
	<style type="text/css">
		body{
			background-color:#d0e4fe;
		}
		table{
			text-align:center;
			width:100%;
			font-size:medium;
			border-collapse:collapse;
			empty-cells:hide;
		}
		tr{
			height:60px;
			width:100px;
			text-align:center;
		}
		td{
			width:100px;
			text-align:center;
			background-color:#d0e4fe;
		}
		div.center{
			text-align:center;
		}
		input{
			width:100px;
		}
		td.valid{
			background-color:#00FF00;
		}
		td.invalid{
			background-color:#B22222;
		}
		div.credit{
			text-align:right;
			font-size:9pt;
		}
		div.output{
			text-align:left;
			font-size:large;
			font-weight: bold
		}
	</style>
</head>
<body>
<h1 align="center">Barrel Jump Lab Calculations</h1>
<br>
<table border="1">
	<tr>
		<td><u>Copied</u><br>Object Mass [kg]</td>
		<td><u>Copied</u><br>Starting Height on Ramp (h) [m]</td>
		<td><u>Copied</u><br>Starting Distance (d) [m]</td>
		<td><u>Average Measured</u><br>Distance from Table (L) [m]</td>
		<td><u>Calculated</u><br>Potential Energy at Top of Ramp [J] (1 point)</td>
		<td><u>Calculated</u><br>Kinetic Energy at Bottom of Ramp [J] (1 point)</td>
		<td><u>Calculated</u><br>Initial Horizontal Velocity at Edge of Table [m/s] (1 point)</td>
		<td><u>Calculated</u><br>Distance From Table (L) [m] (2 points)</td>
		<td>% Error (1 point)</td>
	</tr>
	
	<!--Row 1-->
	<tr>
		<td class="normal"><?php echo $a1; ?></td>
		<td class="normal"><?php echo $b1; ?></td>
		<td class="normal"><?php echo $c1; ?></td>
		<td class="normal"><?php echo $d1; ?></td>
		<?php
			if($e1>0 && ($e1 >= (($a1*9.8*$b1)*.9)) && ($e1 <= (($a1*9.8*$b1)*1.1))){
				echo '<td class = "valid">';
				$correct++;
				$score++;
			}
			else{
				echo '<td class = "invalid">';
				
			}
		?><?php echo $e1 ?></td>
		
		<?php
			if($f1>0 && ($f1 >= (($a1*9.8*$b1)*.9)) && ($f1 <= (($a1*9.8*$b1)*1.1))){
				echo '<td class = "valid">';
				$correct++;
				$score++;
			}
			else{
				echo '<td class = "invalid">';
			}
		
		?><?php echo $f1 ?></td>
		
		<?php
			if($g1>0 && ($g1 >= (sqrt(2*$f1/$a1))*.9) && ($g1 <= ((sqrt(2*$f1/$a1)))*1.1)){
				echo '<td class = "valid">';
				$correct++;
				$score++;
			}
			else{
				echo '<td class = "invalid">';
			}
		
		?><?php echo $g1 ?></td>
		
		<?php
			if($h1>0 && ($h1 >= (($g1*0.43)*.9)) && ($h1 <= (($g1*0.43)*1.1))){
				echo '<td class = "valid">';
				$correct++;
				$score = $score+2;
			}
			else{
				echo '<td class = "invalid">';
			}
		
		?><?php echo $h1 ?></td>
		
		<?php
		if($i1>0 && $d1>0){
			$perror = (abs(($h1-$d1)/$h1))*100;
			if(( $i1 >= ($perror*.9)) && ( $i1 <= ($perror*1.1))){
				echo '<td class = "valid">';
				$correct++;
				$score++;
			}
			else{
				echo '<td class = "invalid">';
			}
		}
		else{
				echo '<td class = "invalid">';
		}
		?><?php echo $i1 ?></td>
	</tr>
	
	
	
	<!--Row 2-->
	<tr>
		<td class="normal"><?php echo $a2; ?></td>
		<td class="normal"><?php echo $b2; ?></td>
		<td class="normal"><?php echo $c2; ?></td>
		<td class="normal"><?php echo $d2; ?></td>
		<?php
		if(($e2>0) && ($e2 >= (($a2*9.8*$b2)*.9)) && ($e2 <= (($a2*9.8*$b2)*1.1))){
			echo '<td class = "valid">';
			$correct++;
			$score++;
		}
		else{
			echo '<td class = "invalid">';
		}
		?><?php echo $e2 ?></td>
		
		<?php
			if($f2>0 && ($f2 >= (($a2*9.8*$b2)*.9)) && ($f2 <= (($a2*9.8*$b2)*1.1))){
				echo '<td class = "valid">';
				$correct++;
				$score++;
			}
			else{
				echo '<td class = "invalid">';
			}
		?><?php echo $f2 ?></td>
		
		<?php
			if($g2>0 && ($g2 >= (sqrt(2*$f2/$a2))*.9) && ($g2 <= ((sqrt(2*$f2/$a2)))*1.1)){
				echo '<td class = "valid">';
				$correct++;
				$score++;
			}
			else{
				echo '<td class = "invalid">';
			}
		?><?php echo $g2 ?></td>
		
		<?php
			if($h2>0 && ($h2 >= (($g2*0.43)*.9)) && ($h2 <= (($g2*0.43)*1.1))){
				echo '<td class = "valid">';
				$correct++;
				$score = $score+2;
			}
			else{
				echo '<td class = "invalid">';
			}
		?><?php echo $h2 ?></td>
		
		<?php
		if($i2>0 && $d2>0){
			$perror = (abs(($h2-$d2)/$h2))*100;
			if(( $i2 >= ($perror*.9)) && ( $i2 <= ($perror*1.1))){
				echo '<td class = "valid">';
				$correct++;
				$score++;
			}
			else{
				echo '<td class = "invalid">';
			}
		}
		else{
			echo '<td class = "invalid">';
		}
		?><?php echo $i2 ?></td>
	</tr>
	
	
	
	
	<!--Row 3-->
	<tr>
		<td class="normal"><?php echo $a3; ?></td>
		<td class="normal"><?php echo $b3; ?></td>
		<td class="normal"><?php echo $c3; ?></td>
		<td class="normal"><?php echo $d3; ?></td>
		<?php
			if($e3>0 && ($e3 >= (($a3*9.8*$b3)*.9)) && ($e3 <= (($a3*9.8*$b3)*1.1))){
				echo '<td class = "valid">';
				$correct++;
				$score++;
			}
			else{
				echo '<td class = "invalid">';
			}
		?><?php echo $e3 ?></td>
		
		<?php
			if($f3>0 && ($f3 >= (($a3*9.8*$b3)*.9)) && ($f3 <= (($a3*9.8*$b3)*1.1))){
				echo '<td class = "valid">';
				$correct++;
				$score++;
			}
			else{
				echo '<td class = "invalid">';
			}
		?><?php echo $f3 ?></td>
		
		<?php
			if($g3>0 && ($g3 >= (sqrt(2*$f3/$a3))*.9) && ($g3 <= ((sqrt(2*$f3/$a3)))*1.1)){
				echo '<td class = "valid">';
				$correct++;
				$score++;
			}
			else{
				echo '<td class = "invalid">';
			}
		?><?php echo $g3 ?></td>
		
		<?php
			if($h3>0 && ($h3 >= (($g3*0.43)*.9)) && ($h3 <= (($g3*0.43)*1.1))){
				echo '<td class = "valid">';
				$correct++;
				$score = $score+2;
			}
			else{
				echo '<td class = "invalid">';
			}
		?><?php echo $h3 ?></td>
		
		<?php
		if($i3>0 && $d3>0){
			$perror = (abs(($h3-$d3)/$h3))*100;
			if(( $i3 >= ($perror*.9)) && ( $i3 <= ($perror*1.1))){
				echo '<td class = "valid">';
				$correct++;
				$score++;
			}
			else{
				echo '<td class = "invalid">';
			}
		}
		else{
			echo '<td class = "invalid">';
		}
		?><?php echo $i3 ?></td>
	</tr>
	
	
	
	
	
	<!--Row 4-->
	<tr>
		<td class="normal"><?php echo $a4; ?></td>
		<td class="normal"><?php echo $b4; ?></td>
		<td class="normal"><?php echo $c4; ?></td>
		<td class="normal"><?php echo $d4; ?></td>
		<?php
			if($e4>0 && ($e4 >= (($a4*9.8*$b4)*.9)) && ($e4 <= (($a4*9.8*$b4)*1.1))){
				echo '<td class = "valid">';
				$correct++;
				$score++;
			}
			else{
				echo '<td class = "invalid">';
			}
		?><?php echo $e4 ?></td>
		
		<?php
			if($f4>0 && ($f4 >= (($a4*9.8*$b4)*.9)) && ($f4 <= (($a4*9.8*$b4)*1.1))){
				echo '<td class = "valid">';
				$correct++;
				$score++;
			}
			else{
				echo '<td class = "invalid">';
			}
		?><?php echo $f4 ?></td>
		
		<?php
			if($g4>0 && ($g4 >= (sqrt(2*$f4/$a4))*.9) && ($g4 <= ((sqrt(2*$f4/$a4)))*1.1)){
				echo '<td class = "valid">';
				$correct++;
				$score++;
			}
			else{
				echo '<td class = "invalid">';
			}
		?><?php echo $g4 ?></td>
		
		<?php
			if($h4>0 && ($h4 >= (($g4*0.43)*.9)) && ($h4 <= (($g4*0.43)*1.1))){
				echo '<td class = "valid">';
				$correct++;
				$score = $score+2;
			}
			else{
				echo '<td class = "invalid">';
			}
		?><?php echo $h4 ?></td>
		
		<?php
		if($i4>0 && $d4>0){
			$perror = (abs(($h4-$d4)/$h4))*100;
			if(( $i4 >= ($perror*.9)) && ( $i4 <= ($perror*1.1))){
				echo '<td class = "valid">';
				$correct++;
				$score++;
			}
			else{
				echo '<td class = "invalid">';
			}
		}
		else{
			echo '<td class = "invalid">';
		}
		?><?php echo $i4 ?></td>
	</tr>
	
	
	
	
	
	<!--Row 5-->
	<tr>
		<td class="normal"><?php echo $a5; ?></td>
		<td class="normal"><?php echo $b5; ?></td>
		<td class="normal"><?php echo $c5; ?></td>
		<td class="normal"><?php echo $d5; ?></td>
		<?php
			if($e5>0 && ($e5 >= (($a5*9.8*$b5)*.9)) && ($e5 <= (($a5*9.8*$b5)*1.1))){
				echo '<td class = "valid">';
				$correct++;
				$score++;
			}
			else{
				echo '<td class = "invalid">';
			}
		?><?php echo $e5 ?></td>
		
		<?php
			if($f5>0 && ($f5 >= (($a5*9.8*$b5)*.9)) && ($f5 <= (($a5*9.8*$b5)*1.1))){
				echo '<td class = "valid">';
				$correct++;
				$score++;
			}
			else{
				echo '<td class = "invalid">';
			}
		?><?php echo $f5 ?></td>
		
		<?php
			if($g5>0 && ($g5 >= (sqrt(2*$f5/$a5))*.9) && ($g5 <= ((sqrt(2*$f5/$a5)))*1.1)){
				echo '<td class = "valid">';
				$correct++;
				$score++;
			}
			else{
				echo '<td class = "invalid">';
			}
		?><?php echo $g5 ?></td>
		
		<?php
			if($h5>0 && ($h5 >= (($g5*0.43)*.9)) && ($h5 <= (($g5*0.43)*1.1))){
				echo '<td class = "valid">';
				$correct++;
				$score = $score+2;
			}
			else{
				echo '<td class = "invalid">';
			}
		?><?php echo $h5 ?></td>
		
		<?php
		if($i5 > 0 && $d5>0){
			$perror = (abs(($h5-$d5)/$h5))*100;
			if(( $i5 >= ($perror*.9)) && ( $i5 <= ($perror*1.1))){
				echo '<td class = "valid">';
				$correct++;
				$score++;
			}
			else{
				echo '<td class = "invalid">';
			}
		}
		else{
			echo '<td class = "invalid">';
		}
		?><?php echo $i5 ?></td>
	</tr>
</table>
<div class="output">
	Name: <?php echo $fname.' '.$lname.'&nbsp &nbsp &nbsp &nbsp Period:'.$period.'&nbsp &nbsp &nbsp &nbsp Score = '.$score.' out of 30, which is '.round((($score/30)*100)).'% &nbsp &nbsp &nbsp &nbsp Date: '.date('D d M Y H:i:s') ?>
</div>
<?php
date_default_timezone_set('US/Mountain');

if(file_exists("results/BarrelJumpAnswers.csv") == false){
	$handle=fopen("results/BarrelJumpAnswers.csv","a");
	fwrite($handle,"Period,Last Name,First Name,% out of 30,Total out of 30,# Correct,Date,Scenario #1,Object Mass #1,Starting Height on Ramp #1,Starting Distance #1,Distance from Table #1,Potential Energy at Top of Ramp #1,Kinetic Energy at Bottom of Ramp #1,Initial horizontal velocity at edge of table #1,Distance from table #1,% Error #1,Scenario #2,Object Mass #2,Starting Height on Ramp #2,Starting Distance #2,Distance from Table #2,Potential Energy at Top of Ramp #2,Kinetic Energy at Bottom of Ramp #2,Initial horizontal velocity at edge of table #2,Distance from table #2,% Error #2,Scenario #3,Object Mass #3,Starting Height on Ramp #3,Starting Distance #3,Distance from Table #3,Potential Energy at Top of Ramp #3,Kinetic Energy at Bottom of Ramp #3,Initial horizontal velocity at edge of table #3,Distance from table #3,% Error #3,Scenario #4,Object Mass #4,Starting Height on Ramp #4,Starting Distance #4,Distance from Table #4,Potential Energy at Top of Ramp #4,Kinetic Energy at Bottom of Ramp #4,Initial horizontal velocity at edge of table #4,Distance from table #4,% Error #4,Scenario #5,Object Mass #5,Starting Height on Ramp #5,Starting Distance #5,Distance from Table #5,Potential Energy at Top of Ramp #5,Kinetic Energy at Bottom of Ramp #5,Initial horizontal velocity at edge of table #5,Distance from table #5,% Error #5,");
	fwrite($handle,"\n");	
        fclose($handle);
}

$handle=fopen("results/BarrelJumpAnswers.csv","a");
	fwrite($handle, $period.",".$lname.",".$fname.",".round((($score/30)*100))."%,".$score.",".$correct.",".date('D d M Y H:i:s').",".$a1.",".$b1.",".$c1.",".$d1.",".$e1.",".$f1.",".$g1.",".$h1.",".$i1.",".$a2.",".$b2.",".$c2.",".$d2.",".$e2.",".$f2.",".$g2.",".$h2.",".$i2.",".$a3.",".$b3.",".$c3.",".$d3.",".$e3.",".$f3.",".$g3.",".$h3.",".$i3.",".$a4.",".$b4.",".$c4.",".$d4.",".$e4.",".$f4.",".$g4.",".$h4.",".$i4.",".$a5.",".$b5.",".$c5.",".$d5.",".$e5.",".$f5.",".$g5.",".$h5.",".$i5);
	fwrite($handle,"\n");

fclose($handle);
?>
<div class="credit">
	Revised 11/1/2018 by AKH
	<br>
	Michael Voecks
	<br>
	Version 1.1
	<br>
	6/30/14
</div>
</body>
</html>